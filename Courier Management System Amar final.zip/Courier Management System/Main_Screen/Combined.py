from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
import sys
import os
import string
from tkinter.ttk import Combobox
from tkinter import ttk
from tkinter import scrolledtext
import sqlite3
import re
def userlogin(widget):
    widget.destroy()
    olduser()
def adminw(widget):
    widget.destroy()
    adminlog()
def fromorderdetails(widget,a_name):
    widget.destroy()
    adminloggedin(a_name)
def orderdetails(a_name):
    ad=Tk()
    ad.title("Admin Screen")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideexit(ad)
    adwelcome3=Label(ad,text='Welcome '+a_name)
    adwelcome3.config(font=('Sans-serif',18,'bold'))
    adwelcome3.pack()
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(ad,image=backrender,command=lambda: fromorderdetails(ad,a_name),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.05)
    addorder=Image.open("D:\\Courier Management System\\Images\\order_add.png")
    addorderrender =ImageTk.PhotoImage(addorder)
    aorderimg = Label(image=addorderrender)
    aorderimg.image = addorderrender
    aorderimg.place(relx=.5, rely=.25 ,anchor=CENTER)
    p_no=Label(ad,text='Phone No')
    p_no.place(relx=.45,rely=.4,anchor=CENTER)
    phone1=IntVar()
    phone=Entry(ad)
    phone.place(relx=.55,rely=.4,anchor=CENTER)
    address=Label(ad,text='Address')
    address.place(relx=.45,rely=.5,anchor=CENTER)
    address1=StringVar()
    addresse=Entry(ad)
    addresse.place(relx=.55,rely=.5,anchor=CENTER)
    def submitnew():
        z=1
        phone1=phone.get()
        try:
            phone11=int(phone1)
        except:
            phone11=0
        if phone11<=999999999 or phone11>9999999999:
            messagebox.showerror("Phone No","Invalid Phone No")
            z=0
        address11=str(addresse.get()).strip()
        if len(address11)>=250:
            messagebox.showerror("Address","Address too long")
            z=0
        OID=0
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('select oid from orderdetail where oid=(select max(oid) from orderdetail)')
        POID=c.fetchone()
        try:
            OID=int(POID[0])+1
        except:
            OID=1
        c.execute('insert into orderdetail(oid,mob_no,address,status) values("%s","%s","%s","%s")'%(OID,phone11,address11,'P'))
        con.commit()
        con.close()
        messagebox.showinfo("Order ID","Order ID is "+str(OID))
        if z==1:
            ad.destroy()
            orderdetails(a_name)
    submit=Button(ad,text="Submit",command= submitnew)
    submit.place(relx=.5,rely=.62,anchor=CENTER)
    ad.mainloop()
def updatew(widget,a_name):
    widget.destroy()
    updatestatus(a_name)
def updatestatus(a_name):
    ad=Tk()
    ad.title("Status Update")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideexit(ad)
    adwelcome3=Label(ad,text='Welcome '+a_name)
    adwelcome3.config(font=('Sans-serif',18,'bold'))
    adwelcome3.pack()
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(ad,image=backrender,command=lambda: fromorderdetails(ad,a_name),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.05)
    addstatus=Image.open("D:\\Courier Management System\\Images\\update.png")
    addstatusrender =ImageTk.PhotoImage(addstatus)
    astatusimg = Label(image=addstatusrender)
    astatusimg.image = astatusimg.place(relx=.5, rely=.25 ,anchor=CENTER)
    p_no=Label(ad,text='Phone No')
    p_no.place(relx=.45,rely=.4,anchor=CENTER)
    phone1=IntVar()
    phone=Entry(ad)
    phone.place(relx=.55,rely=.4,anchor=CENTER)
    take_oid=StringVar()
    getorder=Label(ad,text='Enter Order ID which are Delivered using comma(,)')
    getorder.place(relx=.4,rely=.5,anchor=CENTER)
    enterorder=Entry(ad)
    enterorder.place(relx=.55,rely=.5,anchor=CENTER)
    def showlist():
        z=1
        phone1=phone.get()
        try:
            phone11=int(phone1)
        except:
            phone11=0
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('select * from orderdetail where mob_no="%s"'%(phone11))
        if c.fetchone() is None:
            messagebox.showerror("Not Available","Phone no does not exists")
            z=0
        con.commit()
        con.close()
        if z==1:
            w1=Label(ad,text='Pending Orders')
            w2=Label(ad,text='Delivered Orders')
            #need to updaate
            con=sqlite3.connect("CMS.db")
            c=con.cursor()
            c.execute('select oid,address from orderdetail where mob_no="%s" and status="P"'%(phone11))
            list=c.fetchall()
            scrollbar = Scrollbar(ad)
            scrollbar.place( x=1500,y=200, height=600 )
            mylist = Listbox(ad, yscrollcommand = scrollbar.set )
            mylist.insert(END,"OID Address")
            for line in list:
                mylist.insert(END,str(line[0])+"   "+str(line[1]))
            mylist.place( x=1150,y=200, height=600,width=300 )
            w1.place(x=1280,y=180)
            scrollbar.config( command = mylist.yview )
            con.commit()
            con.close()
            con=sqlite3.connect("CMS.db")
            c=con.cursor()
            c.execute('select oid,address from orderdetail where mob_no="%s" and status="D"'%(phone11))
            list=c.fetchall()
            scrollbar = Scrollbar(ad)
            scrollbar.place( x=0,y=200, height=600 )
            mylist = Listbox(ad, yscrollcommand = scrollbar.set )
            mylist.insert(END,"OID Address")
            for line in list:
                mylist.insert(END,str(line[0])+"   "+str(line[1]))
            mylist.place( x=50,y=200, height=600,width=300 )
            w2.place(x=180,y=180)
            scrollbar.config( command = mylist.yview )
            con.commit()
            con.close()
    sho=Button(ad,text="Show List",command= showlist)
    sho.place(relx=.65,rely=.4,anchor=CENTER)
    def submitnew():
        take_oid1=enterorder.get()
        take_oid=take_oid1.split(",")
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        messagebox.showinfo("Enter Order ID","Entered Order ID is/are "+str(take_oid))
        for i in take_oid:
            c.execute('update orderdetail set status="D" where oid="%s"'%(int(i)))
            #c.execute('select * from orderdetail where status="D" and oid="%s"'%(i))
            #print(c.fetchone())
        con.commit()
        con.close()
    submit=Button(ad,text="Submit",command= submitnew)
    submit.place(relx=.5,rely=.62,anchor=CENTER)
    ad.mainloop()
def addneworder(widget,a_name):
    widget.destroy()
    orderdetails(a_name)
def addnewadmin(widget,a_name):#need change
    widget.destroy()
    naw=Tk()#newadmin window
    naw.title("Add New Admin Screen")
    naw.attributes('-fullscreen',True)
    #logoimg
    logo(naw)
    #side icons
    sideexit(naw)
    log=Label(naw,text='Add Admin')
    log.config(font=('Script-typeface',30,'bold'))
    log.place(relx=.5,rely=.2,anchor=CENTER)
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(naw,image=backrender,command=lambda: fromorderdetails(naw,a_name),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)
    adminimg=Image.open("D:\\Courier Management System\\Images\\add_admin.png")
    adminrender=ImageTk.PhotoImage(adminimg)
    aimg = Label(image=adminrender)
    aimg.image = adminrender
    aimg.place(relx=.5, rely=.3 ,anchor=CENTER)
    aname=Label(naw,text='Admin ID')
    aname.place(relx=.45,rely=.4,anchor=CENTER)
    adminname=Entry(naw)
    adminname.place(relx=.55,rely=.4,anchor=CENTER)
    adminname.focus_set()#cahange
    pswrd=Label(naw,text='Password')
    pswrd.place(relx=.45,rely=.45,anchor=CENTER)
    password=Entry(show="*")
    password.place(relx=.55,rely=.45,anchor=CENTER)
    def onsubmit():
        text1=adminname.get()
        text2=password.get()
        z=1
        A=1
        adminname1=text1.strip()
        adminname11=str(adminname1)
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from admin WHERE AID="%s"' % (adminname11))
        if (len(adminname11)<4):
            messagebox.showerror("Admin ID","Admin ID should contain atlest 4 character")
            A=0
        elif not re.search("[a-z]", adminname11):
            messagebox.showerror("Admin ID","Admin ID should contain small letter")
            A=0
        elif re.search("[A-Z]", adminname11):
            A=0
            messagebox.showerror("Admin ID","Capital letters are not allowed in Admin ID")
        elif re.search("[@_&%]",adminname11):
            messagebox.showerror("Admin ID","Admin ID should not contain _,@ or $ special letter")
            A=0
        elif re.search("\s", adminname11):
            messagebox.showerror("Admin ID","Admin ID should not contain space")
            A=0
        elif c.fetchone() is not None:
            messagebox.showerror("Not Available","Admin ID already taken Please try another")
            A=0
        con.commit()
        con.close()
        password1=text2.strip()
        password123=str(password1)
        if (len(password123)<8):
            messagebox.showerror("Password","Password should contain atlest 8 character")
            z=0
        elif not re.search("[a-z]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 small letter")
            z=0
        elif not re.search("[A-Z]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 capital letter")
            z=0
        elif not re.search("[0-9]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 small letter")
            z=0
        elif not re.search("[_@$]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 of _,@ or $ special letter")
            z=0
        elif re.search("\s", password123):
            messagebox.showerror("Password","Password should not contain space")
            z=0
        else:
            z=1
        if A==1 and z==1:
            con=sqlite3.connect("CMS.db")
            c=con.cursor()
            c.execute('insert into admin(AID,Password) values(?,?)',(adminname11,password123))
            con.commit()
            con.close()
            messagebox.showinfo("Admin Info","Admin ID:-"+str(adminname11)+"\n Admin Password is"+str(password123))
    submit=Button(naw,text="Add Admin",command= onsubmit)
    submit.place(relx=.45,rely=.5,anchor=CENTER)
    naw.mainloop()
def orderlistw(a_name):
    ad=Tk()
    ad.title("Admin Screen")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideexit(ad)
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(ad,image=backrender,command=lambda: fromorderdetails(ad,a_name),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)
    adwelcome3=Label(ad,text='Welcome '+a_name)
    adwelcome3.config(font=('Sans-serif',18,'bold'))
    adwelcome3.pack()
    label1=Label(ad,text="Delivered Orders")
    label2=Label(ad,text="Pending Orders")
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select * from orderdetail where status="P"')
    list=c.fetchall()
    scrollbar = Scrollbar(ad)
    scrollbar.place( x=1500,y=200, height=600 )
    mylist = Listbox(ad, yscrollcommand = scrollbar.set )
    mylist.insert(END,"OID  Phone No     Address")
    for line in list:
        mylist.insert(END,str(line[0])+"   "+str(line[1])+"   "+str(line[2]))
    mylist.place( x=1150,y=200, height=600,width=300 )
    label2.place(x=1280,y=180)
    scrollbar.config(command = mylist.yview )
    con.commit()
    con.close()
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select * from orderdetail where status="D"')
    list=c.fetchall()
    scrollbar = Scrollbar(ad)
    scrollbar.place( x=0,y=200, height=600 )
    mylist = Listbox(ad, yscrollcommand = scrollbar.set )
    mylist.insert(END,"OID  Phone No     Address")
    for line in list:
        mylist.insert(END,str(line[0])+"   "+str(line[1])+"   "+str(line[2]))
    mylist.place( x=50,y=200, height=600,width=300 )
    label1.place(x=180,y=180)
    scrollbar.config( command = mylist.yview )
    con.commit()
    con.close()
    ad.mainloop()
def userorderlistw(username):
    user=Tk()
    user.title("User Window")
    user.attributes('-fullscreen',True)
    #logoimg
    logo(user)
    #side icons
    sideexit(user)
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(user,image=backrender,command=lambda: back2afterlog(user,username),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select f_name from userdetail where username="%s"'%(username))
    f_name1=c.fetchone()
    c.close()
    f_name=str(f_name1[0])
    userwelcome3=Label(user,text='Welcome '+f_name)
    userwelcome3.config(font=('Sans-serif',18,'bold'))
    userwelcome3.pack()
    label1=Label(user,text="Delivered Orders")
    label2=Label(user,text="Pending Orders")
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select mob_no from userdetail where username="%s"'%(username))
    phone1=c.fetchone()
    phone=int(phone1[0])
    c.execute('select * from orderdetail where mob_no="%s" and status="P"'%(phone))
    list=c.fetchall()
    scrollbar = Scrollbar(user)
    scrollbar.place( x=1500,y=200, height=600 )
    mylist = Listbox(user, yscrollcommand = scrollbar.set )
    mylist.insert(END,"OID  Phone No     Address")
    for line in list:
        mylist.insert(END,str(line[0])+"   "+str(line[1])+"   "+str(line[2]))
    mylist.place( x=1150,y=200, height=600,width=300 )
    label2.place(x=1280,y=180)
    scrollbar.config(command = mylist.yview )
    con.commit()
    con.close()
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select * from orderdetail where mob_no="%s" and status="D"'%(phone))
    list=c.fetchall()
    scrollbar = Scrollbar(user)
    scrollbar.place( x=0,y=200, height=600 )
    mylist = Listbox(user, yscrollcommand = scrollbar.set )
    mylist.insert(END,"OID  Phone No     Address")
    for line in list:
        mylist.insert(END,str(line[0])+"   "+str(line[1])+"   "+str(line[2]))
    mylist.place( x=50,y=200, height=600,width=300 )
    label1.place(x=180,y=180)
    scrollbar.config( command = mylist.yview )
    con.commit()
    con.close()
    user.mainloop()
def orderlist(widget,a_name):
    widget.destroy()
    orderlistw(a_name)
def userorderlist(widget,u_name):
    widget.destroy()
    userorderlistw(u_name)
def adminreset(adminid):
    ad=Tk()
    ad.title("Admin Screen")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideexit(ad)

    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    def logina():
        ad.destroy()
        adminloggedin(adminid)
    bimg=Button(ad,image=backrender,command=logina,bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)
    adwelcome3=Label(ad,text='Welcome '+adminid)
    adwelcome3.config(font=('Sans-serif',18,'bold'))
    adwelcome3.pack()
    reset=Image.open("D:\\Courier Management System\\Images\\forgot_password.png")
    resetrender =ImageTk.PhotoImage(reset)
    resetimg = Label(image=resetrender)
    resetimg.image = resetrender
    resetimg.place(relx=.5, rely=.2 ,anchor=CENTER)
    olpassw=Label(ad,text="Old Password").place(relx=.48,rely=.4,anchor=CENTER)
    oldpass=Entry(ad,show="*")
    oldpass.place(relx=.6,rely=.4,anchor=CENTER)
    old=StringVar()
    pswrd=Label(ad,text='New Password')
    pswrd.place(relx=.48,rely=.5,anchor=CENTER)
    password11=StringVar()#for getting password
    password=Entry(ad,show="*")
    password.place(relx=.6,rely=.5,anchor=CENTER)
    def submitnew():
        A=1
        old=oldpass.get()
        old1=str(old)
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('select * from admin where AID="%s" and Password="%s"'%(adminid,old1))
        if c.fetchone() is None:
            messagebox.showerror("Old Password","Incorrect Password Entered")
            A=0
        con.close()
        if A==1:
            password11=password.get()
            password11=password11.strip()
            password123=str(password11)
            if (len(password123)<8):
                messagebox.showerror("Password","Password should contain atlest 8 character")
                z=0
            elif not re.search("[a-z]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 small letter")
                z=0
            elif not re.search("[A-Z]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 capital letter")
                z=0
            elif not re.search("[0-9]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 small letter")
                z=0
            elif not re.search("[_@$]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 of _,@ or $ special letter")
                z=0
            elif re.search("\s", password123):
                messagebox.showerror("Password","Password should not contain space")
                z=0
            else:
                z=1
            if password11=="":
                messagebox.showerror("Blank","Please enter password")
                z=0
            if z==1:
                con=sqlite3.connect("CMS.db")
                c=con.cursor()
                c.execute('update admin set Password="%s" where AID="%s"'%(password123,adminid))
                messagebox.showinfo("Updated","Password Updated")
                con.commit()
                con.close()
                ad.destroy()
                adminlog()

    submit=Button(ad,text="Submit",command= submitnew).place(relx=.5,rely=.6,anchor=CENTER)

    ad.mainloop()
def adminloggedin(adminid):
    a_name=str(adminid).strip()
    ad=Tk()
    ad.title("Admin Screen")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideexit(ad)
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(ad,image=backrender,command=lambda: adminw(ad),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)
    adwelcome3=Label(ad,text='Welcome '+a_name)
    adwelcome3.config(font=('Sans-serif',18,'bold'))
    adwelcome3.pack()
    addorder=Image.open("D:\\Courier Management System\\Images\\order_add.png")
    addorderrender =ImageTk.PhotoImage(addorder)
    aorderimg = Label(image=addorderrender)
    aorderimg.image = addorderrender
    aorderimg.place(relx=.2, rely=.25 ,anchor=CENTER)
    addorderButton=Button(ad,text="Add new Order",command=lambda: addneworder(ad,a_name))
    addorderButton.place(relx=.2,rely=.33,anchor=CENTER)
    addstatus=Image.open("D:\\Courier Management System\\Images\\update.png")
    addstatusrender =ImageTk.PhotoImage(addstatus)
    astatusimg = Label(image=addstatusrender)
    astatusimg.image = addstatusrender
    astatusimg.place(relx=.5, rely=.25 ,anchor=CENTER)
    addstatusButton=Button(ad,text="Update Order",command=lambda: updatew(ad,a_name))
    addstatusButton.place(relx=.5,rely=.33,anchor=CENTER)
    pending=Image.open("D:\\Courier Management System\\Images\\detail.png")
    pendingrender =ImageTk.PhotoImage(pending)
    pendingimg = Label(image=pendingrender)
    pendingimg.image = pendingrender
    pendingimg.place(relx=.8, rely=.25 ,anchor=CENTER)
    pendingButton=Button(ad,text="Orders",command=lambda: orderlist(ad,a_name))#new fun pending
    pendingButton.place(relx=.8,rely=.33,anchor=CENTER)
    addadmin=Image.open("D:\\Courier Management System\\Images\\add_admin.png")
    addadminrender =ImageTk.PhotoImage(addadmin)
    aadminimg = Label(image=addadminrender)
    aadminimg.image = addadminrender
    aadminimg.place(relx=.35, rely=.55 ,anchor=CENTER)
    addadminButton=Button(ad,text="Add new Admin",command=lambda: addnewadmin(ad,a_name))
    addadminButton.place(relx=.35,rely=.63,anchor=CENTER)
    reset=Image.open("D:\\Courier Management System\\Images\\forgot_password.png")
    resetrender =ImageTk.PhotoImage(reset)
    resetimg = Label(image=resetrender)
    resetimg.image = resetrender
    resetimg.place(relx=.65, rely=.55 ,anchor=CENTER)
    def reset():
        ad.destroy()
        adminreset(a_name)
    resetButton=Button(ad,text="Reset Password",command= reset)#new fun pending
    resetButton.place(relx=.65,rely=.63,anchor=CENTER)

    Button(ad, text = 'See Feedbacks', font = ('arial', 13), bd = 3, command = lambda: seefeed(ad), width = 15).place(relx = .5, rely = .85, anchor = CENTER)
    ad.mainloop()
def seefeed(win):
    win.destroy()
    window = Tk()
    window.title('See Feedbacks')
    window.attributes('-fullscreen', True)
    logo(window)
    #side buttons
    sideicons(window)
    #feedback
    feedimg = Image.open("D:\\Courier Management System\\Images\\feed.png")
    feedrend = ImageTk.PhotoImage(feedimg)
    fdimg = Label(image = feedrend)
    fdimg.image = feedrend
    fdimg.place(relx = .5, rely = .15, anchor = CENTER)
    #feedback database on tkinter
    tree = ttk.Treeview(window, column = ("column1", "column2"), show='headings')
    tree.heading("#1", text="Email")
    tree.column("#1", minwidth = 300, width = 100)
    tree.heading("#2", text="Feedback")
    tree.column("#2", minwidth = 600, width = 1000)
    tree.place(relx = .5, rely = .3, anchor = N)

    conn = sqlite3.connect("cmsfeed.db")
    cur = conn.cursor()
    cur.execute("select * from cmsfeed")
    rows = cur.fetchall()
    for row in rows:
        tree.insert("", END, values = row)
    conn.close()
    window.mainloop()
def adminlog():
    ad=Tk()
    ad.title("Admin Screen")
    ad.attributes('-fullscreen',True)
    #logoimg
    logo(ad)
    #side icons
    sideicons(ad)
    adminimg=Image.open("D:\\Courier Management System\\Images\\Admin.png")
    adminrender =ImageTk.PhotoImage(adminimg)
    aimg = Label(image=adminrender)
    aimg.image = adminrender
    aimg.place(relx=.5, rely=.3 ,anchor=CENTER)
    aname=Label(ad,text='AdminID')
    aname.place(relx=.45,rely=.4,anchor=CENTER)

    adminname=Entry(ad)
    adminname.place(relx=.55,rely=.4,anchor=CENTER)
    adminname.focus_set()
    pswrd=Label(ad,text='Password')
    pswrd.place(relx=.45,rely=.45,anchor=CENTER)
    password=Entry(ad,show="*")#
    password.place(relx=.55,rely=.45,anchor=CENTER)
    def onsubmit():
        an=adminname.get()
        ans=str(an)
        ps=password.get()
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from admin WHERE AID="%s" AND Password="%s"' % (an,ps))
        if c.fetchone() is not None:
            ad.destroy()
            adminloggedin(ans)#after login through admin window
        else:
            loginprompt()
        con.commit()
        con.close()
    def default():
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('delete from admin where AID="admin"')
        c.execute('select * from admin where AID="admin"')
        if c.fetchone() is None:
            c.execute('insert into admin(AID,Password) values("%s","%s")'%("admin","Admin@123"))
        con.commit()
        con.close()
        messagebox.showinfo("Reset","Admin and Password reset to default for more ask the developer")
    forgot=Button(ad,text="Reset Password",command= default)
    forgot.place(relx=.45,rely=.50,anchor=CENTER)
    submit=Button(ad,text="Login",command= onsubmit)
    submit.place(relx=.55,rely=.50,anchor=CENTER)
    ad.mainloop()
#side icons
def sideback(w):
    #rhs buttons & icons
    backimg = Image.open("D:\\Courier Management System\\Images\\Back1.png")
    backrender = ImageTk.PhotoImage(backimg)
    bimg = Button(w, image = backrender, command = lambda: back(w), bd = 0)
    bimg.image = backrender
    bimg.place(relx = .9, rely = .04)
def sideexit(w):
    #exit image
    exitimg = Image.open("D:\\Courier Management System\\Images\\Exit1.png")
    exitrender = ImageTk.PhotoImage(exitimg)
    eimg = Button(w, image = exitrender, command = w.destroy, bd = 0)
    eimg.image = exitrender
    eimg.place(relx = .95, rely = .04)
def sideicons(w):
    sideback(w)
    sideexit(w)
#logo
def logo(w):
    logwelcome1=Label(w,text='Welcome to')
    logwelcome2=Label(w,text='Courier Management System')
    logwelcome1.config(font=('Sans-serif',24,'bold'))
    logwelcome2.config(font=('Script-typeface',30,'bold'))
    logwelcome1.pack()
    logwelcome2.pack()
    logoimg=Image.open("D:\\Courier Management System\\Images\\transit.png")
    logorender=ImageTk.PhotoImage(logoimg)
    lgimg = Label(image=logorender)
    lgimg.image=logorender
    lgimg.place(relx=.05,rely=.052,anchor=CENTER)
#track package
def trackpre(widget):
    widget.destroy()
    trackw()
#cost estimator
def costpre(widget):
    widget.destroy()
    costestm()
#feedback
def feedbackpre(widget):
    widget.destroy()
    feedback()
#main Window
def mainscreen():
    ms=Tk()
    ms.title("Home Screen")
    ms.attributes('-fullscreen',True)
    #creating tables if not exists
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('create table if not exists user(username varchar(25) Primary Key,Password varchar(15) NOT NULL)')
    c.execute('create table if not exists userdetail(username Foriegn Key refrences user,f_name varchar(20) not null,m_name varchar(20),l_name varchar(20),gender char(1),reg_no number(8),mob_no number(10),emailid varchar(250))')
    c.execute('create table if not exists orderdetail(oid int Primary Key,mob_no number(10),address varchar(250),status char(1))')
    c.execute('create table if not exists admin(AID varchar(25) Primary Key,Password varchar(15) NOT NULL)')
    con.commit()
    con.close()
    #creating table complete
    #Welcome text
    mswelcome1=Label(ms,text='Welcome')
    mswelcome2=Label(ms,text='Courier Management System')
    mswelcome1.config(font=('Sans-serif',24,'bold'))
    mswelcome2.config(font=('Script-typeface',30,'bold'))
    mswelcome1.pack()
    mswelcome2.pack()
    #new user, register, track, feedback buttons
    userbtn = Button(ms, text = "New User", command = lambda: passnew(ms), font = ('verdana', 13))
    exuserbtn = Button(ms, text = "Existing User", command = lambda: userlogin(ms), font = ('verdana', 13))
    adminbtn = Button(ms, text = "Admin Login", command = lambda: adminw(ms), font = ('verdana', 13))
    trackbtn = Button(ms, text="Track Consignment", command = lambda: trackpre(ms), font = ('verdana', 13))
    feedbtn = Button(ms, text = "Feedback", command = lambda: feedbackpre(ms), font = ('verdana', 13))
    costbtn = Button(ms, text = "Calculate Postage", command = lambda: costpre(ms), font = ('roboto', 13))
    #homepage icons
    #new user
    userimg = Image.open("D:\\Courier Management System\\Images\\newuser.png")
    userrender = ImageTk.PhotoImage(userimg)
    #existing user (register)
    exuserimg = Image.open("D:\\Courier Management System\\Images\\exuser.png")
    exuserrend = ImageTk.PhotoImage(exuserimg)
    #admin
    adminimg = Image.open("D:\\Courier Management System\\Images\\admin.png")
    adminrend = ImageTk.PhotoImage(adminimg)
    #track
    trackimg = Image.open("D:\\Courier Management System\\Images\\track.png")
    trackrend = ImageTk.PhotoImage(trackimg)
    #feedback
    feedimg = Image.open("D:\\Courier Management System\\Images\\feed.png")
    feedrend = ImageTk.PhotoImage(feedimg)
    #cost estimator
    costimg = Image.open("D:\\Courier Management System\\Images\\cost.png")
    costrend = ImageTk.PhotoImage(costimg)
    #alignment of images on screen
    #new user
    nuimg = Label(image = userrender)
    nuimg.image = userrender
    #existing user
    euimg = Label(image = exuserrend)
    euimg.image = exuserrend
    #admin
    adimg = Label(image = adminrend)
    adimg.image = adminrend
    #track
    trimg = Label(image = trackrend)
    trimg.image = trackrend
    #feedback
    fdimg = Label(image = feedrend)
    fdimg.image = feedrend
    #cost estimator
    cstimg = Label(image = costrend)
    cstimg.image = costrend
    #alignment of icons
    nuimg.place(relx = .25, rely = .30, anchor = CENTER)
    euimg.place(relx = .50, rely = .30, anchor = CENTER)
    adimg.place(relx = .75, rely = .30, anchor = CENTER)
    trimg.place(relx = .25, rely = .57, anchor = CENTER)
    fdimg.place(relx = .75, rely = .57, anchor = CENTER)
    cstimg.place(relx = .50, rely = .57, anchor = CENTER)
    #corresponding buttons
    userbtn.place(relx = .25, rely = .40, anchor = CENTER)
    exuserbtn.place(relx = .50, rely = .40, anchor = CENTER)
    adminbtn.place(relx = .75, rely = .40, anchor = CENTER)
    trackbtn.place(relx = .25, rely = .67, anchor = CENTER)
    costbtn.place(relx = .50, rely = .67, anchor = CENTER)
    feedbtn.place(relx = .75, rely = .67, anchor = CENTER)
    #logo image
    logoimg=Image.open("D:\\Courier Management System\\Images\\transit.png")
    logorender=ImageTk.PhotoImage(logoimg)
    lgimg = Label(image=logorender)
    lgimg.image=logorender
    lgimg.place(relx=.05,rely=.052,anchor=CENTER)
    #exit button
    exitimg=Image.open("D:\\Courier Management System\\Images\\Exit.png")
    exitrender=ImageTk.PhotoImage(exitimg)
    eimg=Button(image=exitrender,command=ms.destroy,bd=0)
    eimg.place(relx=.5,rely=.85,anchor=CENTER)
    exitButton=Button(ms,text="Exit Program",command=ms.destroy)
    exitButton.place(relx=.5,rely=.95,anchor=CENTER)
    ms.mainloop()
def back(widget):
    widget.destroy()
    mainscreen()
def loginprompt():
    messagebox.showwarning('WARNING','Please enter valid username and password')
def login(u,p,k):
    username=u
    password=p
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('SELECT * from user WHERE username="%s" AND Password="%s"' % (username, password))
    if c.fetchone() is not None:
        k.destroy()
        afterlogin(u)
    else:
        loginprompt()
    con.commit()
    con.close()
def passnew(widget):
    widget.destroy()
    newuserw()
def olduser():
    loginw=Tk()
    loginw.title("Login Screen")
    loginw.attributes('-fullscreen',True)
    #user login label
    log=Label(loginw,text='User Login')
    log.config(font=('Script-typeface',30,'bold'))
    log.place(relx=.5,rely=.2,anchor=CENTER)
    #side sideicons
    sideicons(loginw)
    #logo text image
    logo(loginw)
    #user login scree image
    userimg=Image.open("D:\\Courier Management System\\Images\\User.png")
    userrender=ImageTk.PhotoImage(userimg)
    uimg = Label(image=userrender)
    uimg.image = userrender
    uimg.place(relx=.5, rely=.3 ,anchor=CENTER)

    #username
    uname=Label(loginw,text='Username')
    uname.place(relx=.45,rely=.4,anchor=CENTER)
    username=Entry(loginw,width=20,bd=2)
    username.place(relx=.55,rely=.4,anchor=CENTER)
    username.focus_set()

    #password
    pswrd=Label(loginw,text='Password')
    pswrd.place(relx=.45,rely=.45,anchor=CENTER)
    password=Entry(show="*",width=20,bd=2)
    password.place(relx=.55,rely=.45,anchor=CENTER)

    #after click on submit button
    def onsubmit():
        text1=username.get()
        text2=password.get()
        login(text1,text2,loginw)

    #after click on track consignment button
    def passtrack():
        loginw.destroy()
        trackw()

    #submit button
    submit=Button(loginw,text="Login",command=lambda: onsubmit(),bd=3,bg='darkblue',fg='white')
    submit.place(relx=.5,rely=.5,anchor=CENTER)

    #newuser user buttons
    Label(loginw, text = "Don't have CMS account! Create a new account: ", font = ('Roboto', 12)).place(relx = .36, rely = .65, anchor = W)
    newuser=Button(loginw,text="Register to CMS",command=lambda: passnew(loginw))
    newuser.place(relx=.62,rely=.65,anchor=CENTER)

    #track button
    track=Button(loginw,text="Track Consignment",command= passtrack)
    track.place(relx=.57,rely=.5,anchor=CENTER)
    loginw.mainloop()
def userreset(widget,username):
    widget.destroy()
    userresetw(username)
def back2afterlog(widget,username):
    widget.destroy()
    afterlogin(username)
def userresetw(username):
    user=Tk()
    user.title("User Window")
    user.attributes('-fullscreen',True)
    userwelcome1=Label(user,text='Welcome to')
    userwelcome2=Label(user,text='Courier Management System')
    userwelcome1.config(font=('Sans-serif',24,'bold'))
    userwelcome2.config(font=('Script-typeface',30,'bold'))
    userwelcome1.pack()
    userwelcome2.pack()
    backimg=Image.open("D:\\Courier Management System\\Images\\Back.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(user,image=backrender,command=lambda: back2afterlog(user,username))
    bimg.image=backrender
    bimg.place(relx=.9,rely=.05)
    exitimg=Image.open("D:\\Courier Management System\\Images\\Exit1.png")
    exitrender=ImageTk.PhotoImage(exitimg)
    eimg=Button(user,image=exitrender,command=user.destroy)
    eimg.place(relx=.95,rely=.05)
    logoimg=Image.open("D:\\Courier Management System\\Images\\transit.png")
    logorender=ImageTk.PhotoImage(logoimg)
    lgimg = Label(image=logorender)
    lgimg.image=logorender
    lgimg.place(relx=.05,rely=.052,anchor=CENTER)
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select f_name from userdetail where username="%s"'%(username))
    f_name1=c.fetchone()
    c.close()
    f_name=str(f_name1[0])
    userwelcome3=Label(user,text='Welcome '+f_name)
    userwelcome3.config(font=('Sans-serif',18,'bold'))
    userwelcome3.pack()
    reset=Image.open("D:\\Courier Management System\\Images\\forgot_password.png")
    resetrender =ImageTk.PhotoImage(reset)
    resetimg = Label(image=resetrender)
    resetimg.image = resetrender
    resetimg.place(relx=.5, rely=.2 ,anchor=CENTER)
    olpassw=Label(user,text="Old Password").place(relx=.48,rely=.4,anchor=CENTER)
    oldpass=Entry(user,show="*")
    oldpass.place(relx=.6,rely=.4,anchor=CENTER)
    old=StringVar()
    pswrd=Label(user,text='Password')
    pswrd.place(relx=.48,rely=.5,anchor=CENTER)
    password11=StringVar()#for getting password
    password=Entry(user,show="*")
    password.place(relx=.6,rely=.5,anchor=CENTER)
    pswrd1=Label(user,text='Re-enter Password')
    pswrd1.place(relx=.48,rely=.6,anchor=CENTER)
    password12=StringVar()#for getting password check
    password1=Entry(user,show="*")
    password1.place(relx=.6,rely=.6,anchor=CENTER)
    def submitnew():
        A=1
        old=oldpass.get()
        old1=str(old)
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('select * from user where username="%s" and Password="%s"'%(username,old1))
        if c.fetchone() is None:
            messagebox.showerror("Old Password","Incorrect Password Entered")
            A=0
        con.close()
        if A==1:
            password11=password.get()
            password12=password1.get()
            password11=password11.strip()
            password12=password12.strip()
            password123=str(password12)
            if (len(password123)<8):
                messagebox.showerror("Password","Password should contain atlest 8 character")
                z=0
            elif not re.search("[a-z]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 small letter")
                z=0
            elif not re.search("[A-Z]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 capital letter")
                z=0
            elif not re.search("[0-9]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 small letter")
                z=0
            elif not re.search("[_@$]", password123):
                messagebox.showerror("Password","Password should contain atlest 1 of _,@ or $ special letter")
                z=0
            elif re.search("\s", password123):
                messagebox.showerror("Password","Password should not contain space")
                z=0
            else:
                z=1
            if password11=="" or password12=="":
                messagebox.showerror("Blank","Please enter password")
                z=0
            if password11!=password12:
                messagebox.showerror("Password not match","Please enter password again")
                z=0
            if z==1:
                con=sqlite3.connect("CMS.db")
                c=con.cursor()
                c.execute('update user set Password="%s" where username="%s"'%(password123,username))
                messagebox.showinfo("Updated","Password Updated")
                con.commit()
                con.close()
                user.destroy()
                olduser()
    submit=Button(user,text="Submit",command= submitnew).place(relx=.5,rely=.8,anchor=CENTER)
    user.mainloop()
def afterlogin(username):
    username1=str(username).strip()
    user=Tk()
    user.title("User Window")
    user.attributes('-fullscreen',True)

    #logo sideicon
    logo(user)

    backimg=Image.open("D:\\Courier Management System\\Images\\Back1.png")
    backrender=ImageTk.PhotoImage(backimg)
    bimg=Button(user,image=backrender,command=lambda: back1(user),bd=0)
    bimg.image=backrender
    bimg.place(relx=.9,rely=.04)

    #side exit
    sideexit(user)

    #takinng firstname
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('select f_name from userdetail where username="%s"'%(username1))
    f_name1=c.fetchone()
    c.close()
    f_name=str(f_name1[0])
    userwelcome3=Label(user,text='Welcome '+f_name)
    userwelcome3.config(font=('Sans-serif',18,'bold'))
    userwelcome3.pack()

    #Buttons
    trackbtn = Button(user, text="Track Consignment", command = lambda: trackpre(user), font = ('arial', 13), bd = 3)
    #reqbtn = Button(user, text = "Submit Courier Request", command = lambda: courierpre(user), font = ('arial', 13), bd = 3)
    costbtn = Button(user, text = "Calculate Postage", command = lambda: costpre(user), font = ('arial', 13), bd = 3)
    #homepage icons
    #courier request
    #reqimg = Image.open("D:\\Courier Management System\\Images\\request.png")
    #reqrend = ImageTk.PhotoImage(reqimg)
    #track
    trackimg = Image.open("D:\\Courier Management System\\Images\\track.png")
    trackrend = ImageTk.PhotoImage(trackimg)
    #cost estimator
    costimg = Image.open("D:\\Courier Management System\\Images\\cost.png")
    costrend = ImageTk.PhotoImage(costimg)
    #alignment of images on screen
    #track
    trimg = Label(image = trackrend)
    trimg.image = trackrend
    #courier request
    #rqimg = Label(image = reqrend)
    #rqimg.image = reqimg
    #cost estimator
    cstimg = Label(image = costrend)
    cstimg.image = costrend
    #alignment of icons
    #rqimg.place(relx = .25, rely = .40, anchor = CENTER)
    trimg.place(relx = .25, rely = .40, anchor = CENTER)
    cstimg.place(relx = .75, rely = .40, anchor = CENTER)
    #corresponding buttons
    #reqbtn.place(relx = .25, rely = .50, anchor = CENTER)
    trackbtn.place(relx = .25, rely = .50, anchor = CENTER)
    costbtn.place(relx = .75, rely = .50, anchor = CENTER)

    reset=Image.open("D:\\Courier Management System\\Images\\forgot_password.png")
    resetrender =ImageTk.PhotoImage(reset)
    resetimg = Label(image=resetrender)
    resetimg.image = resetrender
    resetimg.place(relx=.7, rely=.70 ,anchor=CENTER)
    resetButton=Button(user,text="Reset Password",command=lambda: userreset(user,username1))
    resetButton.place(relx=.7,rely=.80,anchor=CENTER)


    #order list button
    pending=Image.open("D:\\Courier Management System\\Images\\detail.png")
    pendingrender =ImageTk.PhotoImage(pending)
    pendingimg = Label(image=pendingrender)
    pendingimg.image = pendingrender
    pendingimg.place(relx=.3, rely=.70 ,anchor=CENTER)
    pendingButton=Button(user,text="Orders",command=lambda: userorderlist(user,username1))
    pendingButton.place(relx=.3,rely=.80,anchor=CENTER)

    user.mainloop()

'''def reqcourier():
    home = Tk()
    home.title("Welcome to CMS")
    home.attributes('-fullscreen', True)
    #heading and icon
    reqimg = Image.open("D:\\Courier Management System\\Images\\request.png")
    reqrender = ImageTk.PhotoImage(reqimg)
    aimg = Label(image = reqrender)
    aimg.image = reqrender
    aimg.place(relx=.5, rely=.05, anchor = N)
    #admin label
    log = Label(home, text = 'Submit an Courier Request', font = ('Script-typeface', 23, 'bold'))
    log.place(relx = .5, rely = .20, anchor = N)
    #rhs buttons & icons
    backimg = Image.open("D:\\Courier Management System\\Images\\Back1.png")
    backrender = ImageTk.PhotoImage(backimg)
    bimg = Button(home, image = backrender, command = lambda: homeback(home), bd = 0)
    bimg.image = backrender
    bimg.place(relx = .02, rely = .04)
    sideexit(home)
    #inputs
    Label(home, text = 'User details:', font = ('arial', 13)).place(relx = .10, rely = .35, anchor = W)
    #username entry
    username1 = StringVar() #for getting username
    uname = Label(home, text = 'Username:', font = ('arial', 14))
    uname.place(relx = .20, rely = .40, anchor = W)
    username = Entry(home, width = 20, bd = 2, font = ('roboto', 13))
    username.place(relx = .35, rely = .40, anchor = CENTER)
    username.focus_set()

    #registration number
    Label(home, text = 'Registration No:', font = ('arial', 14)).place(relx = .47, rely = .40, anchor = W)
    regno = Entry(home, width = 10, bd = 2, font = ('roboto', 13))
    regno.place(relx = .57, rely = .40, anchor = W)

    #mobile number
    ph = Label(home, text = 'Mobile No:', font = ('arial', 14))
    ph.place(relx = .70, rely = .40, anchor = W)
    phone = Entry(home, width = 20, bd = 2, font = ('roboto', 13))
    phone.place(relx = .84, rely = .40, anchor = CENTER)

    #courier details
    Label(home, text = 'Courier details:', font = ('arial', 13)).place(relx = .10, rely = .50, anchor = W)
    #travel from and to
    Label(home, text = 'From:', font = ('arial', 14)).place(relx = .20, rely = .55, anchor = W)
    Label(home, text = 'Lovely Professional University, Phagwara, 144411', font = ('arial', 13)).place(relx = .25, rely = .55, anchor = W)
    Label(home, text = 'To:', font = ('arial', 14)).place(relx = .55, rely = .55, anchor = W)
    to = Entry(home, width = 50, font = ('roboto', 13), bd = 2)
    to.place(relx = .58, rely = .55, anchor = W)

    #weight
    wgh = Label(home, text = 'Weight (in gms):', font = ('arial', 14))
    wgh.place(relx = .20, rely = .65, anchor = W)
    weight = Entry(home, width = 8, font = ('roboto', 13), bd = 2)
    weight.place(relx = .30, rely = .65, anchor = W)

    #Travel Distance
    dist = Label(home, text = 'Travel Distance (in kms):', font = ('arial', 14))
    dist.place(relx = .40, rely = .65, anchor = W)
    distance = Entry(home, width = 8, font = ('roboto', 13), bd = 2)
    distance.place(relx = .55, rely = .65, anchor = W)

    #Delivery Type
    ty = Label(home, text = 'Delivery Type:', font = ('arial', 14))
    ty.place(relx = .65, rely = .65, anchor = W)
    deltype = Combobox(home, font=('Arial', 14))
    deltype['values'] = ('Parcel', 'Express Parcel', 'Speed Post')
    deltype.current(0)
    deltype.place(relx = .75, rely = .65, anchor = W)

    #cost label
    Label(home, text = 'Estimated Cost:', font = ('arial', 14)).place(relx = .20, rely = .75, anchor = W)
    costlabel = Label(home, text = "", font = ('arial', 14), fg = 'darkblue')
    costlabel.place(relx = .47, rely = .75, anchor = CENTER)

    #consignment number
    cons = Label(home, text = '', font = ('arial', 14), fg = 'darkblue')
    cons.place(relx = .20, rely = .80, anchor = W)
    #cost checker
    #check cost button
    def checkthecost():
        cost=costcheck(deltype,weight, distance)
        costlabel.configure(text=str(cost))
    Button(home, text = 'Check cost', bd = 0, font = ('roboto', 12), command = checkthecost.place(relx = .32, rely = .75, anchor = CENTER)
    #submit chekcer
    def checkreq():
        str3 = phone.get()
        str4 = to.get()
        str5 = weight.get()
        #str5 = float(str5)
        str6 = distance.get()
        #str6 = float(str6)
        str7 = deltype.get()
        dk1, dk2, dk3, dk5, dk6, dk4 = 0,0,0,0,0,0
        if str3 and str4 and str5 and str6:
            elif len(str3) != 10 or re.search('[a-zA-Z]', str3):
                messagebox.showerror('Failure', 'Phone number should contain only 10 digits!')
                dk3 = 1
            elif len(str4) < 8:
                messagebox.showerror('Failure', 'To address is too short!')
                dk4 = 1
            elif str5 == '0' or str5 == '':
                messagebox.showerror('Failure', 'Weight cannot be zero!')
                dk5 = 1
            elif str6 == '3' or str6 == '2' or str6 == '1' or str6 == '' or str6 == '0':
                messagebox.showerror('Failure', 'Distance should be at least 4 Kms')
                dk6 = 1
            if dk1 == 0 and dk2 == 0 and dk4 == 0 and dk5 == 0 and dk6 == 0 and dk3 == 0:
                #changing data types
                str1 = str(str1)
                str2 = int(str2)
                str3 = int(str3)
                str4 = str(str4)
                str5 = float(str5)
                str6 = float(str6)
                str7 = str(str7)
                status = 'On the Way'
                #costcheck(weight, distance, deltype)
                #consignment number generator
                consign = random.randint(1000000, 9999999)
                rnd = 'Consignment number for the courier request: {}'.format(consign)
                cons.configure(text = rnd)
                #saving to database
                #establish the connection to database
                conn = sq.connect('cmsreq.db')
                #enter user data to database
                conn.execute("insert into cmsreq values (?,?,?,?,?,?,?,?,?)",(str1, str2, str3, str4, str5, str6, str7,consign,status,))
                #commit the changes and close the connection to database
                conn.commit()
                conn.close()
                messagebox.showinfo('Request Updated Successfully', 'Request Updated Successfully with consignment no: {}'.format(consign))
                homepagepre(home)
        else:
            messagebox.showerror('Failure', 'Enter valid values!')

    #submit button
    Button(home, text = 'Submit Request', bd = 3, font = ('roboto', 13, 'bold'), bg = 'darkblue', fg = 'white', command = checkreq, width = 15).place(relx = .55, rely = .87, anchor = CENTER)
    Button(home, text = 'Reset', bd = 3, font = ('roboto', 13, 'bold'), bg = 'darkred', fg = 'white', command = lambda: reqcourierpre(home), width = 10).place(relx = .45, rely = .87, anchor = CENTER)
    home.mainloop()

#Request Courier
def courierpre(win):
    win.destroy()
    reqcourier()

def reqcourierpre(win):
    win.destroy()
    reqcourier()
'''
def newdatauser(username,password,firstname,middlename,lastname,email,gender,phone,reg):
    print("Welcome now your data will be saved")
    con=sqlite3.connect("CMS.db")
    c=con.cursor()
    c.execute('insert into user(username,Password) values("%s","%s")'%(username,password))
    c.execute('insert into userdetail(username,f_name,m_name,l_name,gender,reg_no,mob_no,emailid) values("%s","%s","%s","%s","%s","%s","%s","%s")'%(username,firstname,middlename,lastname,gender,reg,phone,email))
    con.commit()
    con.close()
def back1(widget):
    widget.destroy()
    olduser()
def newuserw():
    new=Tk()
    new.title("Register")
    new.attributes('-fullscreen',True)

    #logo
    logo(new)

    #login label
    log=Label(new,text='Register New User')
    log.config(font=('Script-typeface',30,'bold'))
    log.place(relx=.5,rely=.2,anchor=CENTER)

    #sideicons
    sideicons(new)

    userimg=Image.open("D:\\Courier Management System\\Images\\User.png")
    userrender=ImageTk.PhotoImage(userimg)
    uimg = Label(image=userrender)
    uimg.image = userrender
    uimg.place(relx=.5, rely=.3 ,anchor=CENTER)
    uname=Label(new,text='Username')
    uname.place(relx=.45,rely=.4,anchor=CENTER)
    username1=StringVar()#for getttin username
    username=Entry(new)
    username.place(relx=.55,rely=.4,anchor=CENTER)
    username.focus_set()
    pswrd=Label(new,text='Password')
    pswrd.place(relx=.45,rely=.45,anchor=CENTER)
    password11=StringVar()#for getting password
    password=Entry(show="*")
    password.place(relx=.55,rely=.45,anchor=CENTER)
    pswrd1=Label(new,text='Re-enter Password')
    pswrd1.place(relx=.45,rely=.47,anchor=CENTER)
    password12=StringVar()#for getting password check
    password1=Entry(show="*")
    password1.place(relx=.55,rely=.47,anchor=CENTER)
    f_name=Label(new,text='First Name')
    f_name.place(relx=.45,rely=.52,anchor=CENTER)
    firstname1=StringVar()#for getting firstname
    firstname=Entry(new)
    firstname.place(relx=.55,rely=.52,anchor=CENTER)
    m_name=Label(new,text='Middle Name')
    m_name.place(relx=.45,rely=.54,anchor=CENTER)
    middlename1=StringVar()#for getting middle name
    middlename=Entry(new)
    middlename.place(relx=.55,rely=.54,anchor=CENTER)
    l_name=Label(new,text='Last Name')
    l_name.place(relx=.45,rely=.56,anchor=CENTER)
    lastname1=StringVar()#for getting lastname
    lastname=Entry(new)
    lastname.place(relx=.55,rely=.56,anchor=CENTER)
    e_mail=Label(new,text='E-Mail ID')
    e_mail.place(relx=.45,rely=.61,anchor=CENTER)
    email1=StringVar()#for getting email
    email=Entry(new)
    email.place(relx=.55,rely=.61,anchor=CENTER)
    def genders():
        selection= var.get()
        if selection==3:
            return 'O'
        elif selection==2:
            return 'F'
        else:
            return 'M'
    var = IntVar()
    gender=Label(new,text='Gender')
    gender.place(relx=.45,rely=.64,anchor=CENTER)
    R1 = Radiobutton(new, text="M", variable=var, value=1,command=genders)
    R1.place(relx=.52,rely=.64,anchor=CENTER)
    R1.focus_set()##already select option nhi hua abhi
    R2 = Radiobutton(new, text="F", variable=var, value=2,command=genders)
    R2.place(relx=.555,rely=.64,anchor=CENTER)
    R3 = Radiobutton(new, text="O", variable=var, value=3,command=genders)
    R3.place(relx=.58,rely=.64,anchor=CENTER)
    p_no=Label(new,text='Phone No')
    p_no.place(relx=.45,rely=.69,anchor=CENTER)
    phone1=IntVar()
    phone=Entry(new)
    phone.place(relx=.55,rely=.69,anchor=CENTER)
    r_no=Label(new,text='Registration No')
    r_no.place(relx=.45,rely=.73,anchor=CENTER)
    reg1=IntVar()
    reg=Entry(new)
    reg.place(relx=.55,rely=.73,anchor=CENTER)
    def submitnew():
        z=1
        A=1
        username1=username.get()
        username1=username1.strip()
        username11=str(username1)
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from user WHERE username="%s"' % (username11))
        if (len(username11)<4):
            z=0
            messagebox.showerror("Username","Username should contain atlest 4 character")
            A=0
        elif not re.search("[a-z]", username11):
            messagebox.showerror("Username","Username should contain small letter")
            z=0
        elif re.search("[A-Z]", username11):
            A=0
            messagebox.showerror("Username","Capital letters are not allowed in username")
        elif re.search("[@_&%]",username11):
            messagebox.showerror("Username","Username should not contain _,@ or $ special letter")
            z=0
        elif re.search("\s", username11):
            messagebox.showerror("Username","Username should not contain space")
            z=0
        elif c.fetchone() is not None:
            messagebox.showerror("Not Available","Username already taken Please try another")
            z=0
        con.commit()
        con.close()
        password11=password.get()
        password12=password1.get()
        password11=password11.strip()
        password12=password12.strip()
        password123=str(password12)
        if (len(password123)<8):
            messagebox.showerror("Password","Password should contain atlest 8 character")
            z=0
        elif not re.search("[a-z]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 small letter")
            z=0
        elif not re.search("[A-Z]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 capital letter")
            z=0
        elif not re.search("[0-9]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 small letter")
            z=0
        elif not re.search("[_@$]", password123):
            messagebox.showerror("Password","Password should contain atlest 1 of _,@ or $ special letter")
            z=0
        elif re.search("\s", password123):
            messagebox.showerror("Password","Password should not contain space")
            z=0
        else:
            z=1
        if password11=="" or password12=="":
            messagebox.showerror("Blank","Please enter password")
            z=0
        if password11!=password12:
            messagebox.showerror("Password not match","Please enter password again")
            z=0
        firstname1=firstname.get()
        firstname1=firstname1.strip()
        firstname11=str(firstname1)
        if firstname1=="":
            messagebox.showerror("Blank","First Name Cann't be leave blank")
            z=0
        if re.search("[_@$]",firstname11):
            messagebox.showerror("Name","First name should not contain _,@ or $ special letter")
            z=0
        else:
            if re.search("[0-9]",firstname11):
                messagebox.showerror("Name","First name should not contain digit")
                z=0
        middlename1=middlename.get()
        middlename1=middlename1.strip()
        middlename11=str(middlename1)
        if re.search("[_@$]",middlename11):
            messagebox.showerror("Name","Middle name should not contain _,@ or $ special letter")
            z=0
        else:
            if re.search("[0-9]",middlename11):
                messagebox.showerror("Name","Middle name should not contain digit")
                z=0
        lastname1=lastname.get()
        lastname1=lastname1.strip()
        lastname11=str(lastname1)
        if re.search("[_@$]",lastname11):
            messagebox.showerror("Name","Last name should not contain _,@ or $ special letter")
            z=0
        else:
            if re.search("[0-9]",lastname11):
                messagebox.showerror("Name","Last name should not contain digit")
                z=0
        email1=email.get()
        email1=email1.strip()
        email11=str(email1)#for further validation
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from userdetail WHERE emailid="%s"' % (email11))
        if email11=="":
            messagebox.showerror("Blank","E-Mail Id Cann't be leave blank")
            z=0
        elif not re.search("[@]",email11):
            messagebox.showerror("E-Mail","Invalid E-Mail")
            z=0
        elif not re.search("[.]",email11):
            messagebox.showerror("E-Mail","Invalid E-Mail")
            z=0
        elif email11[-4:]!=".com":
            print(email11[-4:])
            messagebox.showerror("E-Mail","Invalid E-Mail")
            z=0
        elif c.fetchone() is not None:
            messagebox.showerror("Not Available","E-mail already exists")
            z=0
        con.commit()
        con.close()
        gender1=genders()
        gender11=str(gender1)
        phone1=phone.get()
        try:
            phone11=int(phone1)
        except:
            phone11=0
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from userdetail WHERE mob_no="%s"' % (phone11))
        if phone11<=999999999 or phone11>9999999999:
            messagebox.showerror("Phone No","Invalid Phone No")
            z=0
        elif c.fetchone() is not None:
            messagebox.showerror("Not Available","Phone no already exists")
            z=0
        con.commit()
        con.close()
        reg1=reg.get()
        try:
            reg11=int(reg1)
        except:
            reg11=0
        if reg11<=9999999 or reg11>99999999:
            messagebox.showerror("Registration No","Invalid Registration No")
            z=0
        con=sqlite3.connect("CMS.db")
        c=con.cursor()
        c.execute('SELECT * from userdetail WHERE reg_no="%s"' % (reg11))
        if c.fetchone() is not None:
            messagebox.showerror("Not Available","Registration no already exists")
            z=0
        con.commit()
        con.close()
        if z==1 and A==1:
            new.destroy()
            newdatauser(username11,password123,firstname11,middlename11,lastname11,email11,gender11,phone11,reg11)
            olduser()
    submit=Button(new,text="Submit",command= submitnew)
    Label(new, text = 'Already have CMS account! Login from here: ', font = ('roboto', 13)).place(relx = .35, rely = .89, anchor = W)
    backl=Button(new,text="Login to CMS",command=lambda: back1(new))
    submit.place(relx=.5,rely=.78,anchor=CENTER)
    backl.place(relx=.6,rely=.89,anchor=CENTER)
    new.mainloop()
#Track package window
def trackw():
    window = Tk()
    window.title("Track the Courier")
    window.attributes('-fullscreen',True)

    #logo
    logo(window)

    #sideicons
    sideicons(window)

    #track image
    adminimg = Image.open("D:\\Courier Management System\\Images\\track.png")
    adminrender = ImageTk.PhotoImage(adminimg)
    aimg = Label(image = adminrender)
    aimg.image = adminrender
    aimg.place(relx = .5, rely=.12, anchor = N)
    #admin label
    log = Label(window, text = 'Track The Courier', font = ('Script-typeface', 23, 'bold'))
    log.place(relx = .5, rely = .3, anchor = N)
    #consignment number
    cons = Label(window, text = 'Consignment Number:', font = ('arial', 14))
    cons.place(relx = .33, rely = .45, anchor = W)
    consnum = Entry(window, width = 20, font = ('roboto', 13), bd = 2)
    consnum.place(relx = .57, rely = .45, anchor = CENTER)
    oid=IntVar()

    #track consignment
    def trackc():
        oid=consnum.get()
        try:
            p=1
            or_id=int(oid)
        except:
            or_id=0
            p=0
            messagebox.showerror("Consignment No","Please enter valid order id or Consignment no")
        if p==1:
            con=sqlite3.connect("CMS.db")
            c=con.cursor()
            c.execute('select status from orderdetail where oid="%s"'%(or_id))
            stat=c.fetchone()
            state=stat[0]
            if state=="D":
                messagebox.showinfo("Delivered","Your Parcel has been delivered")
            else:
                messagebox.showinfo("Pending","Your Parcel has not been delivered")
            con.close()
    #submit button
    Button(window, text = 'Submit', font = ('roboto', 13), command = trackc, bd = 3).place(relx = .57, rely = .52, anchor = CENTER)


    #keep window opened
    mainloop()
def costcheck(cm,x1,x2):
    if cm == 'Parcel':
        xc = 1
    elif cm == 'Express Parcel':
        xc = 2
    else:
        xc = 3
    try:
        z=1
        wg=int(x1)
        dist=int(x2)
    except:
        messagebox.showerror("Error","Please enter valid entry")
        z=0
    basecharge=50
    if(xc==1):
        basecharge=10
    elif(xc==2):
        basecharge=30
    else:
        basecharge=50
    chargeper5km=1
    weightcharge=20
    if(wg<=2000):
        weightcharge=20
    elif(wg>2000 and wg<=10000):
        weightcharge=50
    elif(wg>10000):
        weightcharge=100
    cost=int((dist*chargeper5km/5)+weightcharge+basecharge)
    if dist<=0 or wg<=0:
        cost=0
    if(z==1):
        return cost
#Cost estimator window
def costestm():
    window = Tk()
    window.title("Cost Estimation")
    window.attributes('-fullscreen',True)

    #logo icons
    logo(window)

    #side sideicons
    sideicons(window)


    log = Label(window, text = 'Postage Cost Estimation', font = ('Script-typeface', 23, 'bold'))
    log.place(relx = .5, rely = .2, anchor = N)
    Label(window, text = 'Please Enter all of the following values:', font = ('roboto', 12)).place(relx = .33, rely = .34, anchor = W)
    #inputs

    #weight
    wgh = Label(window, text = 'Weight of Courier (in gms):', font = ('arial', 14))
    wgh.place(relx = .33, rely = .40,anchor = W)
    weight = Entry(window, width = 20, font = ('roboto', 13), bd = 2)
    weight.place(relx = .55, rely = .40, anchor = W)
    weight.focus_set()

    #Travel Distance
    dist = Label(window, text = 'Travel Distance (in kms):', font = ('arial', 14))
    dist.place(relx = .33, rely = .47, anchor = W)
    distance = Entry(window, width = 20, font = ('roboto', 13), bd = 2)
    distance.place(relx = .55, rely = .47, anchor = W)

    #Delivery Type
    ty = Label(window, text = 'Courier Delivery Type:', font = ('arial', 14))
    ty.place(relx = .33, rely = .54, anchor = W)
    deltype = Combobox(window, font=('Arial', 14))
    deltype['values'] = ('Parcel', 'Express Parcel', 'Speed Post')
    deltype.current()
    deltype.place(relx = .55, rely = .54, anchor = W)

    #cost label
    costlabel = Label(window, text = '', font = ('arial', 15, 'bold'))
    costlabel.place(relx = .50, rely = .61, anchor = CENTER)

    #submit checker
    def getdata():
        cm = deltype.get()
        x1 = weight.get()
        x2 = distance.get()
        cost=costcheck(cm,x1,x2)
        costlabel.configure(text = "Total cost is "+str(cost))

    #submit button
    Button(window, text = 'Submit', font = ('roboto', 13), command = getdata, bd = 3).place(relx = .50, rely = .70, anchor = CENTER)

    #keep window opened
    mainloop()

#Feedback window
def feedback():
    window = Tk()
    window.title("Feedback")
    window.attributes('-fullscreen',True)
    #cmsfeed
    conn = sqlite3.connect('cmsfeed.db') #creates file (if not exists)
    conn.execute('''Create table if not exists cmsfeed
        (email varchar(25) not null,
        feedback varchar(500) not null);''')
    conn.commit()
    conn.close()
    #images
    sideicons(window)
    #admin image
    adminimg = Image.open("D:\\Courier Management System\\Images\\feed.png")
    adminrender = ImageTk.PhotoImage(adminimg)
    aimg = Label(image = adminrender)
    aimg.image = adminrender
    aimg.place(relx = .5, rely=.05, anchor = N)
    #admin label
    log = Label(window, text = 'Give Your Feedback', font = ('Script-typeface', 23, 'bold'))
    log.place(relx = .5, rely = .20, anchor = N)
    #labels and input
    mail = Label(window, text = 'Enter your Email:', font = ('arial', 14))
    mail.place(relx = .35, rely = .35, anchor = W)
    feedmail = Entry(window, width = 25, font = ('arial', 13), bd = 2)
    feedmail.place(relx = .55, rely = .35, anchor = CENTER)
    aw = Label(window, text = 'Please Give Your Feedback:', font = ('arial', 14))
    aw.place(relx = .20, rely = .43, anchor = W)
    scrolW = 80
    scrolH = 13
    feed = scrolledtext.ScrolledText(window, width = scrolW, height = scrolH, font = ('arial', 14), wrap = WORD)
    feed.place(relx = .5, rely = .47, anchor = N)
    #submit
    def checkfeed():
        str1 = feedmail.get()
        str1 = str(str1)
        str2 = feed.get("1.0", END)
        str2 = str(str2)
        if str1 and str2:
            if re.search('[@]', str1) is None:
                messagebox.showerror('Failure', 'Please enter valid Email')
            elif len(str2) < 5:
                messagebox.showerror('Failure', 'Feedback must contain 5 words!')
            else:
                #add feedback in the database cmsfeed.db
                #establish the connection to database
                conn = sqlite3.connect('cmsfeed.db')
                #add feedback to database
                conn.execute("insert into cmsfeed values (?,?)", (str1, str2,))
                #commit changes and close the connection
                conn.commit()
                conn.close()
                messagebox.showinfo('Success', 'Thank you for Feedback.')
                back(window)
        else:
            messagebox.showerror('Failure', 'Please fill the email and Feedback!')

    submit = Button(window, text = 'Submit Feedback', command = checkfeed, font = ('Roboto', 13, 'bold'), bd = 3, bg = 'darkblue', fg = 'white')
    submit.place(relx = .5, rely = .85, anchor = CENTER)


mainscreen()
