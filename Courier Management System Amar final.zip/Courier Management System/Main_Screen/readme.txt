Important tips to run Courier Management System program:
1. Paste this folder in D drive directly
2. Do not execute/run "cmsuser.py", "cmsfeed.py" file (unless cmsuser.db & cmsfeed.db files are deleted)
3. Do not alter data.csv file